from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import *
from .forms import *
from django.contrib import messages
import uuid
from Job_portal.settings import EMAIL_HOST_USER
from django.core.mail import send_mail
from django.contrib.auth import authenticate



def c_index(request):
    return render(request,"index.html")


def c_registration(request):
    if request.method=='POST':
        username=request.POST.get('username')
        email=request.POST.get('email')
        password=request.POST.get('password')
        cpassword=request.POST.get('cpassword')
        if password==cpassword:
            #checking
            if User.objects.filter(username=username).first():
                messages.success(request,'Username already taken')
                return redirect(c_registration)
            if User.objects.filter(email=email).first():
                messages.success(request,'email already exist')
                return redirect(c_registration)
            user_obj=User(username=username,email=email)
            user_obj.set_password(password)
            user_obj.save()
            auth_token=str(uuid.uuid4())
            profile_obj=companyprofile.objects.create(user=user_obj,auth_token=auth_token)
            profile_obj.save()
            send_mail_regis(email,auth_token)
            return redirect(success)
        else:
            return HttpResponse("<h1 style='color:blue;text-align:center'>password entered incorrectly</h1>")
    return render(request,'register.html')



def send_mail_regis(email,token):
    subject = "Your account has been verified"
    message = (f'click the link to verify your account '
               f'http://127.0.0.1:8000/verify/{token}')
    email_from = EMAIL_HOST_USER
    recipient = [email]
    send_mail(subject, message, email_from, recipient)


def success(request):
    return render(request,'success.html')

def verify(request,auth_token):
    profile_obj=companyprofile.objects.filter(auth_token=auth_token).first()
    if profile_obj:
        if profile_obj.is_verified:
            messages.success(request,'your account is already verified')
            return redirect(c_login)
        profile_obj.is_verified=True
        profile_obj.save()
        messages.success(request,'your account has been verified')
        return redirect(c_login)
    else:
        return redirect(error)

def error(request):
    return render(request,'error.html')

def c_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user_obj= User.objects.filter(username=username).first()
        if user_obj is None:
            messages.success(request,'company not found')
            return redirect(c_login)
        profile_obj=companyprofile.objects.filter(user=user_obj).first()
        if not profile_obj.is_verified:
            messages.success(request,'profile not verified check your mail inbox')
            return redirect(c_login)
        user = authenticate(username=username,password=password)
        if user is None:
            messages.success(request,'Incorrect email or password')
            return redirect(c_login)
        obj=companyprofile.objects.filter(user=user)
        return render(request,'company.html',{'obj':obj})
    return render(request,'login.html')




def user_register(request):
    if request.method=="POST":
        a=userFom(request._post)
        if a.is_valid():
            user=a.cleaned_data["username"]
            ema=a.cleaned_data["email"]
            d=a.cleaned_data["dob"]
            if "mob" in a.changed_data:  
                mb = a.cleaned_data["mob"] 
            edu=a.cleaned_data["education"]
            pa=a.cleaned_data["password"]
            cp=a.cleaned_data["cpassword"]
            if pa==cp:
                f=userModel1(username=user,email=ema,dob=d,education=edu,password=pa,mob=mb,)
                f.save()
                return render(request,"user_login.html")
            else:
                return HttpResponse("Passord Does Not match")
        else:
            return HttpResponse("Invalid Data")
    else:
        return render(request,"user_register.html")




def user_login(request):
    if request.method=="POST":
        ema=request.POST.get("email")
        passs=request.POST.get("pas")
        alldata=userModel1.objects.all()
        for i in alldata:
            if i.email==ema and i.password==passs:
                uname=i.username
                emaill=i.email
                dobbb=i.dob
                mb=i.mob
                ql=i.education
                pwd=i.password
                id=i.id
                data={"username":uname,"email":emaill,"dob":dobbb,"password":pwd,"education":ql,"mob":mb,"id":id}
                return render(request,"user.html",{"data":data})
        else:
            return HttpResponse("User Not Found ")
    return render(request,"user_login.html")

# def userdisplay(request):
#     data=userModel1.objects.all()
#     user=[]
#     emailid=[]
#     education=[]
#     mob=[]
#     dob=[]
#     id=[]
#     for i in data:
#         user.append(i.username)
#         emailid.append(i.email)
#         education.append(i.education)
#         mob.append(i.mob)
#         dob.append(i.dob)
#         id.append(i.id)
#     a=zip(user,emailid,id,education,mob,dob)
#     return render(request,"user.html",{"a":a})


def updateuser(request,id):
    p=userModel1.objects.get(id=id)
    if request.method=="POST":
        
        
            p.username=request.POST.get("username")
            p.email =request.POST.get("email")
            p.education = request.POST.get("education")
            p.dob =request.POST.get("dob")
            p.mob = request.POST.get("mob")
            p.save()
            return redirect(user_login)
        
    else:
        return render(request,"user_edit.html",{"p":p}) 
    
    