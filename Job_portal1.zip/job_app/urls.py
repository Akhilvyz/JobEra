from django.urls import path
from .views import *

urlpatterns=[
    path("",c_index,name="c_index"),
    path("clogin",c_login,name="login"),
    path("send",c_registration,name="register"),
    path("success",success),
    path("verify/<auth_token>",verify),
    path("error",error),
    path("user_register/",user_register,name="user_register"),
    path("user_login",user_login,name="user_login"),
    path("updateuser",updateuser,name="updateuser"),
    path("edituser/<int:id>/",updateuser,),
]