from django.db import models
from django.contrib.auth.models import User



class companyprofile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    auth_token=models.CharField(max_length=100) #passing a link to the email for the registation
    is_verified=models.BooleanField(default=False)
    created_at=models.DateTimeField(auto_now_add=True)
    

class userModel1(models.Model):
    username=models.CharField(max_length=10)
    email=models.EmailField()
    dob=models.DateField()
    mob=models.CharField(max_length=10)
    education=models.CharField(max_length=20)
    password=models.CharField(max_length=10)
    cpassword=models.CharField(max_length=10)