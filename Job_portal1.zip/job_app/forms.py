from django import forms

class userFom(forms.Form):
    username=forms.CharField(max_length=10)
    email=forms.EmailField()
    dob=forms.DateField()
    mob=forms.CharField(max_length=10)
    education=forms.CharField(max_length=20)
    password=forms.CharField(max_length=10)
    cpassword=forms.CharField(max_length=10)
